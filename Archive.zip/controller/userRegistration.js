const UserRegistration = require('../models/userRegister');
const sendEmail = require('../utils/sendemail').sendMail;
const LoginUser = require('../models/login');
 
exports.userRegistration = async(req, res)=>{
   
   // var userInfo = req.body;
    const user = new UserRegistration(req.body);
    const isUser = await UserRegistration.findOne({email:req.body.email})
    if(isUser){
        res.json({
            status: 500,
            message: "Email Already Exists",
            fieldMsg: 'All fields are required',
        });
    }
    else{
       const newUser =  await user.save();
       const allUser = await UserRegistration.find()
       var prevId = allUser[allUser.length-2].registrationnumber
       const updateUser = await UserRegistration.findByIdAndUpdate(
           {
               _id : newUser._id
           },
           {
              $set : { registrationnumber:prevId+1}
           },
           {
               upsert : true
           }
       )
       var userData = await UserRegistration.findById({_id: newUser._id})
      // console.log(userData);
       const {name, email, phone, password} = userData;
       var fileName = "Your Registration Details From BAS\n"+ "Your Registration Number "+ userData.registrationnumber + "\nName :"+ name + "\n " +"Email :"+ email +"\n" +"Phone: "+phone + "\n" + "Password: " + password
    //    console.log(name)
    //    console.log(email)
    //    console.log(phone)
    //    console.log(password)
       sendEmail(['shamshad3300@gmail.com',email],fileName,1);

       res.json({
        status: 201,
        message: "user registered",
        body: updateUser

     }); 
    }
}

exports.loginUser = async(req,res)=>{
    // userLoginDetails = req.body
    // console.log(userLoginDetails);
    console.log(req.body);
    try{
        
    const userLogin = await UserRegistration.findOne({registrationnumber: req.body.registrationnumber});
    console.log(userLogin);
    if(!userLogin){
        res.json({
            status: 404,
            message: 'User not registered',
        })
    }else{
       
        if(userLogin.password === req.body.password){
            // const userLoginData = new LoginUser({isLoggedin: true, userId: userLogin._id})
            //  await userLoginData.save()
            const {password, ...otherData} =  userLogin._doc;
            console.log(otherData);
            res.json({
                status: 200,
                message:'user loggedin',
                body: otherData
            })
        }else{
            res.json({
                status: 404,
                message: "invalid credentials"
            })
        }
    }
    }catch(err){
        res.status(404).json({message: 'something went wrong'})
        console.log("in login error" ,err);
    }
}

exports.loginState = async(req, res)=>{

   try{
    const loginStateData = await LoginUser.find();

    if(loginStateData){
        res.json({
            status: 200,
            message: 'user loggedin',
            response: loginStateData
        })
    }
   }catch(err){
        console.log('user loggedin state',err);
   }
  
}

exports.forgetPasword = async(req,res)=>{
    console.log(req.body);
    try{ 
        const forgetPassword  = await UserRegistration.findOne({email: req.body.email});
        if(forgetPassword){

            const {registrationnumber, name, email, phone, password} = forgetPassword
        //    console.log(registrationnumber,name,email,phone,password)

            let fileName = `Your Registration Details From Bhartiya Aviation Services\n\n Registration number: ${registrationnumber} \n Name: ${name} \n E-mail: ${email} \n Phone: ${phone} \n Password: ${password} \n` 
            sendEmail(email, fileName,1);

            res.json({
                status: 200,
                message: "Your Detail Has Been Send You Registered E-mail Id  Go Check Your E-mail Inbox",
            });
        }else{
            res.json({
                status: 404,
                message: 'This E-mail Can Not Be Found Please Enter Registered Email'
            });
        }
    }catch(err){
        console.log("forget password ", err);
    }
}