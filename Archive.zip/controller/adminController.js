const AdminDB = require('../models/admin');
const cookie = require('cookie');


//  exports.createAdmin = async(req,res)=>{

//     let adminData = req.body
//     console.log(adminData)
//     try{
//         const adminObj = new AdminDB(adminData);
//         const admin = await adminObj.save();
//         if(admin){
//             res.json({
//                 status: 201,
//                 mesage: 'Admin Registered',
//                 response: admin
//             });
//         }else{
//             res.json({
//                 status: 404,
//                 message: 'Admin Not Found'
//             });
//         }


//     }catch(err){
//         res.json({
//             status: 500,
//             mesage: 'Internal Server Error'
//         })
//     }

//  }


 exports.adminLogin = async(req,res)=>{

    const loginDetails = req.body;
    console.log(loginDetails)

    try{
        const adminLoggedin = await AdminDB.findOne({email: loginDetails.email, password:loginDetails.password});        
        if(adminLoggedin){

            res.json({
                status: 200,
                message:'Admin Logged In',
                response: adminLoggedin
            });
        }else{
            res.json({
                status: 404,
                message: 'Wrong Credentials'
            });
        }
    }catch(err){
        res.json({
            status: 500,
            message: 'Internal Server Error'
        });
    }

 }