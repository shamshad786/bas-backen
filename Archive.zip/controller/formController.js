const express = require("express")
const FormData = require("../models/formData")
const JobPost = require("../models/post")
const ContactForm = require('../models/contactform')
const sendEmail = require('../utils/sendemail').sendMail;


exports.postFormData = async (req,res)=>{
    var formParams = req.body
    var postId = req.body.postId
    console.log(postId);
    try{
    if(postId){
      await JobPost.findById(postId).then(async(result)=>{
            var postName = result.name
            var price = result.price       
            console.log("POST DATA",postName,price);
            formParams["price"]=price
            formParams["postapply"]=postName
            // var getRes = await FormData.findOne({email : req.body.email})
            // if(getRes){
            //     await 
            //     console.log(getRes);
            //     res.json({
            //         status:200,
            //         message:"email already present"
            //     })
            // }
            const formData = new FormData(formParams)
            var response = await formData.save()
            console.log("response ID",response._id);
            var allRes = await FormData.find()
            console.log("length",allRes.length);
            var prevId = allRes[allRes.length-2].applicationnumber
            var finalResponse = await FormData.findOneAndUpdate(
                {
                    _id : response._id
                },
                {
                    $set : {applicationnumber:prevId+1}
                },
                {
                    upsert: true,
                }
            )
            console.log("Updated response",finalResponse);
            res.json({ 
                status : 200,
                message : "Form Submitted Successfully",
                body : response
            })
        })
        }
    }catch(err){
        res.json({ 
            status : 500,
            message : "Error in form Submission",
        })
    }
    
}
exports.getAllFormData = async (req,res)=>{

    try{
    var response = await FormData.find().lean()
    console.log("All records fetched");
    res.json({
        status: 200,
        message:"all records fetched",
        body:response
    })
    }
    catch(err){
        console.log("Error in getting all form records");
        res.json({
            status:500,
            message:"error in getting all records"
        })
    }

   

}

exports.postContactForm = async(req,res)=>{
    try{
       // console.log(req.body);
        const contactFormdata = req.body;

        console.log(contactFormdata) 

        const contactForm =  new ContactForm(contactFormdata);
        const contactSavedData = await contactForm.save();

        var contactFormDataById = await  ContactForm.findById({_id: contactSavedData._id })

        //console.log(contactFormDataById)

        const {name, email, phone, message} =  contactFormDataById;

        var contactFormSendData = "Candidate Query Form Data\n" + "Name : "+ name + "\n" + "E-mail :"+ email + "\n" + "Phone : " + phone + "\n" + " message : " + message

        sendEmail(['shamshad3300@gmail.com'],contactFormSendData,1);

        res.json({
            status: 201,
            message: "Your Query Has Been Sent To BAS We'll Contact You As Soon As Possible",
            body: contactSavedData
        });
    }catch(err){
        console.log(err)
        res.json({
            status: 500,
            message: "error in submitting contact form"
        })
    }
}


exports.getSingleForm = async(req,res)=>{
    const id = req.params.id
    console.log(id);
    try{
        const singleForm = await FormData.findOne({_id:id});
        res.json({
            status: 200,
            message: 'success',
            response: singleForm
        });

    }catch(err){

        res.json({
            status: 404,
            message: 'failed'
        });

    }

}


exports.getUserForms = async(req,res)=>{
    const id = req.params.id
    console.log(id);
    try{
        const userForms = await FormData.find({userId:id});
        console.log(userForms);
        res.json({
            status: 200,
            message: 'success',
            response: userForms
        });

    }catch(err){

        res.json({
            status: 404,
            message: 'failed'
        });

    }

}

