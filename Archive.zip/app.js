const express = require("express")
const dotenv = require('dotenv');
dotenv.config();
const app = express()
const path = require("path");
const morgan = require("morgan")
const mongooseConnect = require("./db")
const formRouter = require("./router/form")
const jobRouter = require("./router/jobpost")
const paymentRouter = require('./router/payment')
const adminRoute = require('./router/admin');
const puppeteer = require('puppeteer')
const userRegister = require('./router/userregistration');
const multer = require('multer')
const cors = require('cors');
const port = process.env.PORT || 5001
app.use(cors());

var root = require('./root');
const res = require("express/lib/response");
const sendMail = require('./utils/sendemail').sendMail;

app.set("view engine" , "ejs");
app.set("views",__dirname + "/public/" + "views");
app.use(express.static(path.join( __dirname, "public")));
app.use(express.json())
mongooseConnect()
app.use(morgan("tiny"))
app.use(formRouter)
app.use(jobRouter)
app.use(paymentRouter)
app.use(userRegister)
app.use(adminRoute)

app.use('/sendemail',(req,res)=>{
    var filename = root+'/'+'website_as_pdf.pdf'
    console.log('root file name ',filename)
    sendMail(['shamshad3300@gmail.com',"info@bhartiyaaviation.in"], filename,0);
    console.log('email send');
})

app.get('/download', (req,res)=>{
    var filename = root+'/'+'website_as_pdf.pdf'
    console.log("in download");
    res.sendFile(filename, (err)=>{
       if(err){
           console.log(err)
       }else{
           console.log(filename);
       }
    });
})


const storage = multer.diskStorage({
    destination: (req,file,cb)=>{
        cb(null, 'images');
       
    },
    filename: (req,file,cb)=>{
        const date =  Date.now()
        const fileName = date + file.originalname
        cb(null, fileName);
    }
});

const upload = multer({

    storage: storage,
    fileFilter: (req,file,cb)=>{
        if(file.mimetype == 'image/png' || file.mimetype == 'image/jpg' || file.mimetype == 'image/jpeg'){
            cb(null, true);
        }else{
            cb(null, false)
            return cb(new Error('Only .png, .jpg, .jpeg are allowed'));
        }
    }
});


app.post('/upload', upload.single('file'), (req,res)=>{

    res.json({
        status: 201,
        message: "Images Uploaded BAS"
    });

    console.log('filePath: ',req.file.path)
});



app.use("/",async(req,res)=>{
    res.send('API Works')

    var url = "https://www.youtube.com/"
    try{
    const browser = await puppeteer.launch({ headless: true});
    const webPage = await browser.newPage();

    await webPage.goto(url, {
        waitUntil: "networkidle0"
    });
    await webPage.pdf({path: 'website_as_pdf.pdf', format: 'A4'});
}catch(err){
    console.log(err);
}
    // const pdf = await webPage.pdf({
    //     printBackground: true,
    //     format: "Letter",
    //     margin: {
    //         top: "20px",
    //         bottom: "40px",
    //         left: "20px",
    //         right: "20px"
    //     }
    // });

    await browser.close();

    // res.contentType("application/pdf");
    // res.send(pdf);
})

app.listen(port,()=>{
    console.log("server is running", port);
})