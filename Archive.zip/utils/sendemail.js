/*const nodemailer = require("nodemailer");
const root = require("../root");
var transport = nodemailer.createTransport({
//   name: "",
 host: "smtp.zoho.com",
  port: 587,
  secure: false,
  auth: {
    user: "rishabh@geeksatweb.com",
    pass: "Rip1996@",
  },
});
exports.sendMail = (email, fileName,emailType) => {
  console.log("in email");
  if(emailType==0){
  var  mailOption = {
    from: "rishabh@geeksatweb.com",
    to: email,
    subject: "Candidate Data",
    text: 'Hello',
    // html: data,
    attachments: [
      {
        fileName: "/website_as_pdf.pdf",
        path: fileName,
        contentType: "application/pdf",
      },
    ],
  };
}
if(emailType==1){
    var mailOption = {
        from: "rishabh@geeksatweb.com",
        to: email,
        subject: "Candidate Data",
        text: fileName,
        // html: data,
      };
}

  transport.sendMail(mailOption, (err, info) => {
    console.log("in mail send");
    console.log(info);
    console.log(err);
  });
};

*/

const nodemailer = require("nodemailer");
const root = require("../root");
var transport = nodemailer.createTransport({
//   name: "",
 host: "smtp.hostinger.com",
  port: 465,
  secure: true,
  auth: {
    user: "info@bhartiyaaviation.in",
    pass: "9TfBJ~d=*x[Gww>$",
  },
});
exports.sendMail = (email,fileName,emailType) => {
  console.log("in email");
  if(emailType==0){
  var  mailOption = {
    from: "info@bhartiyaaviation.in",
    to: email,
    subject: "Candidate Application Form",
    text: 'Hello',
    // html: data,
    attachments: [
      {
        fileName: "/website_as_pdf.pdf",
        path: fileName,
        contentType: "application/pdf",
      },
    ],
  };
}
if(emailType==1){
    var mailOption = {
        from: "info@bhartiyaaviation.in",
        to: email,
        subject: "Candidate information",
        text: fileName,
        // html: data,
      };
}

  transport.sendMail(mailOption, (err, info) => {
    console.log("in mail send");
    console.log(info);
    console.log(err);
  });

  console.log('this is pdf file link',fileName)
};
