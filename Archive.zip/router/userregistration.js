const express = require('express')
 const router = express.Router()

 const  userRegisterController = require('../controller/userRegistration');

router.post('/userregistration', userRegisterController.userRegistration );
router.post('/login', userRegisterController.loginUser );
router.get('/loginstate', userRegisterController.loginState );
router.post('/forget', userRegisterController.forgetPasword);

module.exports = router;