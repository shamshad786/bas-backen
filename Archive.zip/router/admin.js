const express = require('express');
const adminController = require('../controller/adminController');
const adminRoute = express.Router();



//adminRoute.post('/admin/register', adminController.createAdmin);
adminRoute.post('/admin/login', adminController.adminLogin)


module.exports =  adminRoute;