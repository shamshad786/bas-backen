const express = require("express")
const formController = require("../controller/formController")
const formRouter = express.Router()

formRouter.post("/formdata",formController.postFormData);
formRouter.get("/formdata",formController.getAllFormData);
formRouter.post("/contactform",formController.postContactForm);
formRouter.get('/formdata/:id', formController.getSingleForm);
formRouter.get('/userdash/:id', formController.getUserForms);



module.exports = formRouter